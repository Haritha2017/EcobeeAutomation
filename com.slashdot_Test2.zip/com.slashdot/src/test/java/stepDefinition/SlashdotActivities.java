package stepDefinition;

import org.testng.annotations.Test;

import com.slashdot.ArticlesPage;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class SlashdotActivities {
	
	
	WebDriver driver;

	 @BeforeMethod
	  public void beforeMethod() {
		  
		  WebDriverManager.chromedriver().setup();
		  driver = new ChromeDriver();
		  driver.manage().window().maximize();
		  driver.get("https://slashdot.org/");

		  
		  
	  }

	
  @Test
  public void slashdotActivities() throws InterruptedException {
	  ArticlesPage page = new ArticlesPage(driver);
	  page.printNoOfArticlesAndIcons();
	  page.randomVoteAndReturnVotedValue();
	
	  
	  
  }
 
  @AfterMethod
  public void afterMethod() {
	  
  }

}
