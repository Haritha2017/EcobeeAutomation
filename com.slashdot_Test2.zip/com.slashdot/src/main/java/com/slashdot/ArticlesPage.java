package com.slashdot;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ArticlesPage {
	WebDriver driver;

	public ArticlesPage(WebDriver driver) {

		PageFactory.initElements(this.driver, driver);
		this.driver = driver;
	}
	@FindBy (xpath="//*[@id='pollBooth']/div/button")
	public WebElement voteNow;
	
	
	
	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getVoteNow() {
		return voteNow;
	}

	public void printNoOfArticlesAndIcons() throws InterruptedException
	{
		
        List<WebElement> latestNews =  driver.findElements(By.className("story"));
        // take everything for icon inside the list 
        List<WebElement> releventicons =  driver.findElements(By.xpath("//*[@class='topic']/a/img"));
        // print total number of latest articles for today 
        System.out.println("Total article for today is : " + latestNews.size());
        for(int i =0;i<latestNews.size();)
        {
   		 System.out.println("Icons  for today is : "+releventicons.get(i).getSize());
   		i++;
   		 break;
   		 }
        Thread.sleep(6000);
   	}
	
	public String randomVoteAndReturnVotedValue() throws InterruptedException
	{
		Thread.sleep(5000);
		Actions a = new Actions(driver);
		List<WebElement> options = driver.findElements(By.xpath("//form[@id='pollBooth']//label")) ;
	    Random random = new Random();
	    int index = random.nextInt(options.size());
	     options.get(index).click();
	    System.out.println("Random poll selected from the list"+" "+options.get(index).getText());
		Thread.sleep(5000);
		String value = options.get(index).getText();
	    WebElement element = driver.findElement(By.xpath("//*[@id='pollBooth']/div/button"));
	    JavascriptExecutor executor = (JavascriptExecutor)driver;
	    executor.executeScript("arguments[0].scrollIntoView();", element);
	    executor.executeScript("arguments[0].click();", element);

	    Thread.sleep(5000);

	    List<WebElement> poolBooth = driver.findElements(By.xpath("//div[@class='pollBooth_view']//div"));
	    for(WebElement booth:poolBooth)
	    {
	    	if(value.contains(booth.getText()))
	    	{
	    	System.out.println("Number of people voted for the random pole"+" "+booth.getText()+""+booth.getSize());


	    }
	    	}
		return value;	
	}
}